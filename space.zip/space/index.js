const { Client, GatewayIntentBits } = require('discord.js');
const { readdirSync } = require('node:fs');
const { Events, Partials, Collection, EmbedBuilder, ChannelType,AttachmentBuilder,ButtonStyle, ActionRowBuilder, ButtonBuilder } = require('discord.js');
const Discord = require("discord.js")
const cityteam = new Client({
  intents:131071
});
let db = require('pro.db')
cityteam.config = require('./config.json')
let prefix = cityteam.config.prefix;
readdirSync('./handlers').forEach(handler => {
    require(`./handlers/${handler}`)(cityteam);
});


//afk...
cityteam.on('messageCreate' , async(devbynqr) => {
  if(devbynqr.author.bot) return;
        let dbx = db.get(`afk_${devbynqr.author.id}`)
      if(dbx) { devbynqr.reply(`> **<a:emoji_42:1075366841884610651> Hey , I've Removed You From Afk , Reason ${dbx.r} <a:realbot:1075365858475524157> **`)
              db.delete(`afk_${devbynqr.author.id}`)
              devbynqr.member.setNickname(dbx.n)}
  
})
cityteam.on('messageCreate' , async(devbynqr) => {
  if(devbynqr.author.bot) return;
  let user = devbynqr.mentions.users.first();
  if(!user) return;
        let dbx = db.get(`afk_${user.id}`)
  if(dbx == null) return;
     devbynqr.reply(`> **<a:emoji_42:1075366841884610651> Hey , ${user.username} Is Unavailble Now , Reason ${dbx.r} <a:realbot:1075365858475524157> **`)
              db.delete(`afk_${devbynqr.author.id}`)
              devbynqr.member.setNickname(dbx.n)
  
})

const { GiveawaysManager } = require("discord-giveaways");
cityteam.giveawaysManager = new GiveawaysManager(cityteam, {
  storage: "./storage/giveaways.json",
  default: {
    botsCanWin: false,
    embedColor: "#2F3136",
    reaction: "🎉",
    lastChance: {
      enabled: true,
      content: `🧭`,
      threshold: 5000,
      embedColor: '#333'
    }
  }
});


 cityteam.on('guildMemberAdd' , async(member) => {
   let welcome = db.get(`welcome_${member.guild.id}`)
   if(member.bot) return;
   let welcomefukenembed = new MessageEmbed()
   .setAuthor({name: member.user.username , iconURL : member.user.displayAvatarURL({dynamic: true})})
   .setFooter({ text : member.user.username , iconURL: member.user.displayAvatarURL({dynamic: true})})
   .setThumbnail(member.user.displayAvatarURL({dynamic: true}))
   .setTimestamp()
   .setDescription(`**
> Hey ${member.user.username} <a:flower:1032658526683811931> 

> Welcome To __${member.guild.name}__ <a:aemoji_:1032657855150567534> 

> Member Id  \`${member.id}\` <a:heart_13:1032657529412526130> 

> For Orders <#${db.get(`orderroom_${member.guild.id}`)}> <a:Yred:1032658857673117737> 

> Enjoy <3 <a:heart_17:1032658518408433764> 
**
`) 
   .setImage(line)
   .setColor("BLACK")
   member.guild.channels.cache.get(welcome).send({ content: `<@!${member.user.id}>` , embeds: [welcomefukenembed]})
 })

cityteam.on('messageCreate', async(message) => {
  if(message.author.bot) return;
  
  if(message.content === prefix+"app") {
 message.delete()
message.channel.send(`**
> تم قبولك في تيم ${message.guild.name} <a:Yred:1032658857673117737>

> برجاء قرائة القوانين جيدا و التفاعل بشكل لائق ف السيرفر لكي لا يتم تصفيتك

1- ممنوع الهزار بلشتايم ، ٥ ايام

2-ممنوع معامله الكلاينت بأسلوب غير لائق ، ٣ ايام

4-تشفير الكلمات التاليه اجباري(نيترو ، حسابات ،روبلوكس ، كريدت ، شدات ، متوفر ، سيرفر ، ستور ، عرض ، ديسكورد ، تركي ، جيفت ، كود ، انستا ، تيكتوك ، كريبتو ، جنيه ، دولار ، فيزا) ، ٤ ايام

5- ممنوع تنزيل اوفر كريدت بس لو حد فتح تكت و طلب بيعلو عادي لان الكريدت ملهاش رتبه , ٣ ايام

6-ممنوع بيع حاجه معكش رتبتها ، ٦ ايام

7-ممنوع تدخل تاخد كلاينت من واحد او تدخل في تيكت عموما ، ٤ ايام

8-ممنوع تزاحم تكت ، كل الي فلتيكت ٤ ايام

9-ممنوع الترويج لاي سيرفر ، تصفيه

10-اي تعامل فوق ٢٠٠ الف اجباري تاخد وسيط

11-في اليوم ع الاقل ٦ اوفرات غير كدا اول مره ورن ٣ ايام تاني مره تصفيه

عدم قرائة القوانين ليس عذرا
القوانين قابله للتعديل في اي وقت

وبرجاء التاكيد علي حضور الميتنج الاسبوعي يوم الجمعه الساعه 7 اجباري!

اجباري وضع اللينك ف البايو الخاص بك بهذه الطريقه
لازم اللينك يكون باين مش مختفي تحت
${message.guild.name} : ${db.get(`srlink_${message.guild.id}`)}

ونورونتا يمعلم **
`)
  }
  if(message.content === prefix+"ref") {
    message.reply(`**
    تم رفضك في فريق ${message.guild.name}
    
   <a:Yred:1032658857673117737>  برجاء تطوير مستواك و التقديم مره اخري **`)
  }
  if(message.content === prefix+"bott") {
    message.reply(`**
> Hello Please Fill The List To Help The Developer ・ اهلا بك برجائ ملئ القائمه لمساعده المبرمج


> 1-Please Put The Name Of The Bot ・ برجاء كتابه اسم البوت

> 2-Please Put Photo Of Bot ・ برجاء ارسال صوره البوت

> 3-Whats The Bot Type(system , etc..) ・ ما هو نوع البوت (سستم , الخ..)


برجاء الصبر حتي ينتهي المبرمج من البوت الخاص بك
**`)
  }

  //
  if(message.content === prefix+"design") {
    message.reply(`**

> Hello Please Fill The List To Help The Designer ・ برجاء ملء الاستماره لمساعده المصمم

> 1-Whats The Name Of Your Server And The Summary ・ ما هو اسم سيرفرك و اختصاره

> 2-Whats The Color Of Your Design ・ ما هو لون التصميم الذي تريده

> 3-Whats The Type Of Design(Classic , Gaming , Store , etc..) ・ ما هو نوع التصميم (كلاسيك , جيمنج , استور , الخ..)

> 4-Do You Have An Example Of Your Design(Optional) ・ هل لديك مثال علي التصميم الذي تريده (اختياري)

> 5-How Many Hours You Want The Design Finished In It ・ كم عدد الساعات التي تريد ان يتم انهاء التصميم فيها

ThankYou , شكرا لكم
**`)
  }
  if(message.content === prefix+"wtseller") {
    message.delete()
    message.channel.send(`
**انتظر سيلر يا غالي ولو محدش رد عليك ف للاسف الطلب مش موجود حاليا وهنحاول نوفره ف اقرب وقت **<a:flower:1032658526683811931>
`)
  }
   if(message.content === prefix+"rep") {
     message.delete()
     message.channel.send({embeds: [
       new MessageEmbed()
       .setTitle(`${message.guild.name} Team Requirements`)
       .setDescription(`**\`-\` للتبليغ علي سيلر  قم باملاء الاستماره حتي نستطيع تعويضك

صاحب البلاغ :
اسم السيلر فالديسكورد :
ايدي السيلر فالديسكورد :
القصه :
قم بارسال الدلائل مع دليل التحويل :
**
`)
       .setFooter({text: `${message.guild.name} Requirements` , iconUrl: message.guild.iconURL()})
       .setTimestamp()
       .setColor("BLUE")
       .setThumbnail(message.guild.iconURL())
     ]})
   }
  if(message.content === "LINK") {
    message.channel.send(`**
> Server Invite Link <a:Yred:1032658857673117737>
{ ${db.get(`srlink_${message.guild.id}`)} }
> Enjoy  <a:flower:1032658526683811931>
**`)
  }
    if(message.content === "Link") {
    message.channel.send(`**
> Server Invite Link <a:Yred:1032658857673117737>
{ ${db.get(`srlink_${message.guild.id}`)} }
> Enjoy  <a:flower:1032658526683811931>
**`)
  }
    if(message.content === "link") {
    message.channel.send(`**
> Server Invite Link <a:Yred:1032658857673117737>
{ ${db.get(`srlink_${message.guild.id}`)} }
> Enjoy  <a:flower:1032658526683811931>
**`)
  }
    if(message.content === "لينك") {
    message.channel.send(`**
> Server Invite Link <a:Yred:1032658857673117737>
{ ${db.get(`srlink_${message.guild.id}`)} }
> Enjoy  <a:flower:1032658526683811931>
**`)
  }
  if(message.content === "لاين") {
    message.delete();
    message.channel.send({embeds: [new MessageEmbed().setColor("BLACK").setImage(line)]})
  }
    if(message.content === "line") {
    message.delete();
    message.channel.send({embeds: [new MessageEmbed().setColor("BLACK").setImage(line)]})
  }
    if(message.content === "خط") {
    message.delete();
    message.channel.send({embeds: [new MessageEmbed().setColor("BLACK").setImage(line)]})
  }
  if(message.content === prefix + "fb") {
    message.reply(`**
<a:heart_13:1032657529412526130> شكرا لاختيارك ${message.guild.name} <a:heart_13:1032657529412526130>

<a:heart_13:1032657529412526130> Thanks For Choosing ${message.guild.name} <a:heart_13:1032657529412526130>


رايك يهمنا , نتمني ان تعطي فيدباك و تذكر بلمنشن ${message.author}

Your opinion matters , Please give feedback and m Mention the name of the person ${message.author}

----------------------------------------------


Here :
 <#${db.get(`fed_${message.guild.id}`)}>
 <#${db.get(`fed_${message.guild.id}`)}>
 **`)
  }
})
cityteam.on("messageCreate" , async(message) => {
  if(message.author.bot) return;
  if(message.content.toLowerCase() === "re") {
  let sellerrole = db.get(`teamrole_${message.guild.id}`)
    if(sellerrole == null) return;
  if(!message.member.roles.cache.has(sellerrole)) return;
  if(!message.channel.name.startsWith("ticket")) return;
  await message.channel.send(`$rename ${message.member.nickname}`)
 await message.delete()

  }
})
cityteam.on("messageCreate" , async(message) => {
  if(message.author.bot) return;
  if(message.content.toLowerCase() === "re") {
      let sellerrole = db.get(`teamrole_${message.guild.id}`)
    if(sellerrole == null) return;
  if(!message.member.roles.cache.has(sellerrole)) return;
  if(!message.channel.name.startsWith("need")) return;
  await message.channel.send(`$rename ${message.member.nickname}`)
 await message.delete()

  }
})

cityteam.on("messageCreate" , async(message) => {
  if(message.author.bot) return;
  if(message.content.toLowerCase() === "dn") {
  let sellerrole = db.get(`teamrole_${message.guild.id}`)
    if(sellerrole == null) return;
  if(!message.member.roles.cache.has(sellerrole)) return;
     message.delete()
     message.channel.send("$close")
     message.channel.send("$transcript")
     message.channel.send(`$rename Done By ${message.member.nickname}`)

  }
})

cityteam.on('messageCreate' , async(message) => {
  if(message.author.bot) return;
  let auto = db.get(`Auto_Line_${message.guild.id}`)
  if(auto == null) return;
  if(auto.includes(message.channel.id)) {
    message.reply({embeds:[
      new MessageEmbed()
      .setColor("BLACK")
      .setImage(line)
    ]})
  }
})

cityteam.on('messageCreate' , async(message) => {
  if(message.author.bot) return;
  let feedbackroom = db.get(`fed_${message.guild.id}`)
  if(message.channel.id != feedbackroom) return;
    message.reply({embeds:[
      new MessageEmbed()
      .setColor("BLACK")
      .setDescription(`**
> Thanks For Giving Us Feedback <a:heart_13:1032657529412526130>

> We Hope You Visit Us Again <a:flower:1032658526683811931>   
**`)
      .setImage(line)
    ]})
  });



cityteam.on("messageCreate", async(message) => {
   if(message.author.bot) return;
   let channel = db.get(`sug_${message.guild.id}`)
  if(channel == null) return;
  if(message.channel.id != channel) return;
  message.channel.send({embeds: [
    new MessageEmbed()
    .setTimestamp()
    .setAuthor({name : message.author.username , iconURL : message.author.displayAvatarURL({ dynamic: true })})
    .setFooter({text : message.author.username , iconURL : message.author.displayAvatarURL({ dynamic: true })})
    .setThumbnail(message.author.displayAvatarURL({dynamic: true}))
    .setDescription(`
**
${message.content}
**
`)
    .setImage(line)
    .setColor("BLACK")
  ]}).then(async(m) => {
    m.react("<a:Ps_decline:1032657690444451890>")
    m.react("<a:Ps_agree:1032657688561188996>")
  })
  message.delete()
})


cityteam.on('messageCreate' , async(devbynqr) => {
  if(devbynqr.author.bot) return;
    let feedbackroom = db.get(`fed_${devbynqr.guild.id}`)
  if(feedbackroom) return;
  if(devbynqr.channel.id != feedbackroom) return;
  let sellerrole = db.get(`teamrole_${devbynqr.guild.id}`)
  let user = devbynqr.mentions.members.first()
  if(!user) return;
  if(!user.roles.cache.has(sellerrole)) return;
  if(devbynqr.author.id === user.id) return;
  db.add(`feedadsf_${user.id}` , 1)
      let levelll = db.get(`level_${devbynqr.author.id}`)
    if(levelll == null) {
      db.set(`level_${devbynqr.author.id}` , {
        xp : 0,
        nid : devbynqr.author.id
      })
    }
      let levell = db.get(`level_${devbynqr.author.id}`)
      let level = levell.xp;

  await db.set(`level_${devbynqr.author.id}` , {
        xp : Math.floor(level + 3),
        nid : devbynqr.author.id
      })
})

cityteam.on('messageCreate' , async(devbynqr) => {
  if(devbynqr.author.bot) return;
  let feedbackroom = db.get(`off_${devbynqr.guild.id}`)
  if(feedbackroom) return;
  if(devbynqr.channel.id != feedbackroom) return;
  db.add(`offersaddf_${user.id}` , 1)
      let levelll = db.get(`level_${devbynqr.author.id}`)
    if(levelll == null) {
      db.set(`level_${devbynqr.author.id}` , {
        xp : 0,
        nid : devbynqr.author.id
      })
    }
      let levell = db.get(`level_${devbynqr.author.id}`)
      let level = levell.xp;

  await db.set(`level_${devbynqr.author.id}` , {
        xp : Math.floor(level + 2),
        nid : devbynqr.author.id
      })
})

cityteam.on('channelCreate', message => {
let ordercategory = db.get(`orcat_${message.guild.id}`)
  if (message.parentId !== ordercategory) return;
  const pricelistembed = new MessageEmbed()
    .setImage(line)
    .setColor("BLACK")
    .setTimestamp()
    .setThumbnail(message.guild.iconURL({dynamic:true}))
    .setDescription(`
**
\`#\`  <a:flower:1032658526683811931> Hello User Pls Select Your Order

\`#\`  <a:flower:1032658526683811931> مرحبا.. رجاء اختيار الطلب الخاص بك
**
==================

>  \`-\` <:drs_netflix11:1032657394179784764> **netflix**



>  \`-\` <:design:1034010907040292935> **design**



>  \`-\` <a:aemoji_:1032657855150567534> **insta**



>  \`-\` <:NitroGaM:1032657393160564887> **nitro**



>  \`-\` <:Visa:1032657400781611068> **visa**



>  \`-\` <a:bot:1034011807985180682> **bot**



>  \`-\` <a:13943:1032657853149872138> **vote**



>  \`-\` <:pubgm_uc:1032665747631132682> **uc**



>  \`-\` <:boost_boost:1032657399162601648> **boost**



>  \`-\` <:mega_spotfay:1032666073289465936> **spotify**



>  \`-\` <:899665368761630730:1032666417616650350> **shahid**



>  \`-\` <:Credits:1032657402966835261> **credit**



>  \`-\` <:TikTok3265:1032657402136383568> **tiktok**
`)
  const row = new MessageActionRow()
    .addComponents(
      new MessageSelectMenu()
        .setCustomId('select')
        .setPlaceholder('Select   Prices Here')
        .addoptions([
          {
            label: 'netflix',
            description: 'netflix prices',

            emoji: '<:drs_netflix11:1032657394179784764>',

            value: 'netflix',
          },
          {
            label: 'design',

            description: 'design prices',
            emoji: '<:design:1034010907040292935>',
            value: 'design',
          },
          {
            label: 'insta',

            description: 'insta prices',
            emoji: '<a:aemoji_:1032657855150567534>',
            value: 'insta',
          }, 
          {
            label: 'nitro',
            description: 'nitro prices',
            emoji: '<:NitroGaM:1032657393160564887>',
            value: 'nitro',
          }, {
            label: 'visa',
            emoji: "<:Visa:1032657400781611068>",
            description: 'visa prices',

            value: 'visa',
          }, {
            label: 'bot',

            emoji: "<a:bot:1034011807985180682>",
            description: 'bot prices',
            value: 'bot',
          }, {
            label: 'vote',
            description: 'votes prices',
            emoji: "<a:13943:1032657853149872138>",
            value: 'vote',
          }, {
            label: 'uc',
            description: 'uc prices',
            emoji: "<:pubgm_uc:1032665747631132682>",
            value: 'uc',
          }, {
            label: 'boost',
            description: 'boost prices',
            emoji: "<:boost_boost:1032657399162601648>",
            value: 'boost',
          }, {
            label: 'spotify',
            description: 'spotify prices',
            emoji: "<:mega_spotfay:1032666073289465936>",
            value: 'spotify',
          }, {
            label: 'shahid',
            description: 'shahid prices',
            emoji: "<:899665368761630730:1032666417616650350>",
            value: 'shahid',
          }, {
            label: 'credit',
            description: 'credit prices',
            emoji: "<:Credits:1032657402966835261>",
            value: 'credit',
          }, {
            label: 'tiktok',
            description: 'tiktok prices',
            emoji: "<:TikTok3265:1032657402136383568>",
            value: 'tiktok',
          }

        ]),
    );
  setTimeout(() => {
    message.send({ embeds: [pricelistembed], components: [row] }).then(message => {
      message.channel.send(`
> **Welcome in __${message.guild.name}__** <a:nqrheart:1034016583103815720>

> **اهلا بك في __${message.guild.name}__** <a:nqrheart:1034016583103815720>

**اتفضل حدد طلبك حتى تتواصل معك الجهة المختصه.** <a:810809703831568384:1032658516449697832>`)
    })
  }, 2000);
})
//
cityteam.on("interactionCreate", (interaction) => {
  if (!interaction.isSelectMenu()) return;

  if (interaction.values == "netflix") {
    const netflixembed = new MessageEmbed()
      .setAuthor(`By  : ${interaction.user.username}`, `${interaction.user.displayAvatarURL()}`)
      .setFooter(`By  : ${interaction.user.username}`, `${interaction.user.displayAvatarURL()}`)
      .setThumbnail(interaction.guild.iconURL({dynamic:true}))
      .setTitle(`\`\#\`\ Netflix Prices In ${interaction.guild.name}`)
      .setDescription(` 

===========

**<:drs_netflix11:1032657394179784764> - Netflix User 1 month : 85k <:Credits:1032657402966835261> **

**<:drs_netflix11:1032657394179784764> - Netflix Acc 1 week : 35k <:Credits:1032657402966835261> **

**<:drs_netflix11:1032657394179784764> - Netflix Acc 1 month : 150K <:Credits:1032657402966835261> **

**<:drs_netflix11:1032657394179784764> - Netflix Acc Full Access 2y : 2.5M <:Credits:1032657402966835261> **

==============

- **__You Can Mention The Seller Click The Button__**

`)
      .setImage(`https://aramobi.com/wp-content/uploads/2021/08/Netflix-768x432.jpg`)
      .setColor("BLACK")

    let row = new MessageActionRow()
      .addComponents(
       but1 = new MessageButton()
          .setCustomId(`netflixbutton`)
          .setLabel("Mention Seller")
          .setEmoji("<:1029138651403272255:1034020020151398420>")
          .setStyle('SUCCESS')
      );
    interaction.reply({ content: `<@${interaction.user.id}>`, embeds: [netflixembed], components: [row] })
  }
  if (interaction.values == "design") {
    const designembed = new MessageEmbed()
      .setAuthor(`By  : ${interaction.user.username}`, `${interaction.user.displayAvatarURL()}`)
      .setFooter(`By  : ${interaction.user.username}`, `${interaction.user.displayAvatarURL()}`)
      .setThumbnail(interaction.guild.iconURL({dynamic:true}))
      .setColor("BLACK")
      .setTitle(`\`\#\`\ Designs Prices In ${interaction.guild.name}`)
      .setDescription(` 
      
==============[]==============

**
> <:design:1034010907040292935> Logo <a:wright:1032657532981887057> 150K <:Credits:1032657402966835261>

> <:design:1034010907040292935> Banner <a:wright:1032657532981887057> 200K <:Credits:1032657402966835261>

> <:design:1034010907040292935> Scrim Reslt <a:wright:1032657532981887057> 170k <:Credits:1032657402966835261>

> <:design:1034010907040292935> Scrim Package <a:wright:1032657532981887057> 300K <:Credits:1032657402966835261>

> <:design:1034010907040292935> Welcome <a:wright:1032657532981887057> 100K <:Credits:1032657402966835261>

> <:design:1034010907040292935> Welcome Players <a:wright:1032657532981887057> 200K <:Credits:1032657402966835261>

> <:design:1034010907040292935> Logo <a:wright:1032657532981887057> 150K <:Credits:1032657402966835261>

> <:design:1034010907040292935> Thumbnail <a:wright:1032657532981887057> 300k <:Credits:1032657402966835261>

> <:design:1034010907040292935> Tournment Package <a:wright:1032657532981887057> 1.5M <:Credits:1032657402966835261>

> <:design:1034010907040292935> Info <a:wright:1032657532981887057> 70k <:Credits:1032657402966835261>

> <:design:1034010907040292935> Posters <a:wright:1032657532981887057> 300K <:Credits:1032657402966835261>

> <:design:1034010907040292935> Discord Package <a:wright:1032657532981887057> 1.5M <:Credits:1032657402966835261>

> <:design:1034010907040292935> Youtube Package <a:wright:1032657532981887057> 700K <:Credits:1032657402966835261>

> <:design:1034010907040292935> Vector Art <a:wright:1032657532981887057> 2.5M <:Credits:1032657402966835261>

> <:design:1034010907040292935> Logo Gif <a:wright:1032657532981887057> 250k <:Credits:1032657402966835261>

> <:design:1034010907040292935> Emoji Gif <a:wright:1032657532981887057> 50k <:Credits:1032657402966835261>

> <:design:1034010907040292935> Gif Lines <a:wright:1032657532981887057> 90K <:Credits:1032657402966835261>

> <:design:1034010907040292935> Gif Frames <a:wright:1032657532981887057> 50K <:Credits:1032657402966835261>

> <:design:1034010907040292935> Gif Banners <a:wright:1032657532981887057> 300K <:Credits:1032657402966835261>

**
==============
ملحوظه اسعار التصاميم ثابته لان كل المصممين عندنا في مستوي عالي


- **__You Can Mention The Seller Click The Button__**
`)
      .setImage("https://9to5mac.com/wp-content/uploads/sites/6/2022/06/photoshop-cloud.jpg?quality=82&strip=all")

    let row = new MessageActionRow()
      .addComponents(
        new MessageButton()
          .setCustomId(`desibutton`)
          .setLabel("Mention Seller")
          .setEmoji("<:1029138651403272255:1034020020151398420>")
          .setStyle('SUCCESS')
      );

    interaction.reply({ content: `<@${interaction.user.id}>`, embeds: [designembed], components: [row] })
  }
  if (interaction.values == "insta") {
    const instaembedembed = new MessageEmbed()
      .setAuthor(`By  : ${interaction.user.username}`, `${interaction.user.displayAvatarURL()}`)
      .setFooter(`By  : ${interaction.user.username}`, `${interaction.user.displayAvatarURL()}`)
      .setThumbnail(interaction.guild.iconURL({dynamic:true}))
      .setColor("BLACK")
      .setTitle(`\`\#\`\ InstaGram Prices In ${interaction.guild.name}`)
      .setDescription(`

===========

**__Followers__**

- **<a:aemoji_:1032657855150567534> - 100 Follower : 15k <:Credits:1032657402966835261> **

- **<a:aemoji_:1032657855150567534> - 500 Follower : 60k <:Credits:1032657402966835261> **

- **<a:aemoji_:1032657855150567534> - 1k Follower : 130k <:Credits:1032657402966835261> **


**__Likes__**


- **<a:aemoji_:1032657855150567534> - 100 Like : 10K <:Credits:1032657402966835261> **

- **<a:aemoji_:1032657855150567534> 500 Like : 50K <:Credits:1032657402966835261> **

- **<a:aemoji_:1032657855150567534> 1k Like : 100K <:Credits:1032657402966835261> **


==============

**ضمان ابدي**
- **__You Can Mention The Seller Click The Button__**
`)
      .setImage("https://img.freepik.com/free-vector/social-media-instagram-banner_228198-596.jpg")

    let row = new MessageActionRow()
      .addComponents(
        new MessageButton()
          .setCustomId(`insbutton`)
          .setLabel("Mention Seller")
          .setEmoji("<:1029138651403272255:1034020020151398420>")
          .setStyle('SUCCESS')
      );

    interaction.reply({ content: `<@${interaction.user.id}>`, embeds: [instaembedembed], components: [row] })
  }
  if (interaction.values == "visa") {
    const visaembedembed = new MessageEmbed()
      .setAuthor(`By  : ${interaction.user.username}`, `${interaction.user.displayAvatarURL()}`)
      .setFooter(`By  : ${interaction.user.username}`, `${interaction.user.displayAvatarURL()}`)
      .setThumbnail(interaction.guild.iconURL({dynamic:true}))
      .setColor("BLACK")
      .setTitle(`\`\#\`\ Visa Prices In ${interaction.guild.name}`)
      .setDescription(`

============


Visa Is Not Availble At This Time


=============

- **__You Can Mention The Seller Click The Button__**
`)
      .setImage("https://media.discordapp.net/attachments/967015425990852648/968612061846310972/images.png")

    let row = new MessageActionRow()
      .addComponents(
        new MessageButton()
          .setCustomId(`visbutton`)
          .setLabel("Mention Seller")
          .setEmoji("<:1029138651403272255:1034020020151398420>")
          .setStyle('SUCCESS')
      );

    interaction.reply({ content: `<@${interaction.user.id}>`, embeds: [visaembedembed], components: [row] })
  }
  if (interaction.values == "nitro") {
    const nitroembedembed = new MessageEmbed()
      .setAuthor(`By  : ${interaction.user.username}`, `${interaction.user.displayAvatarURL()}`)
      .setFooter(`By  : ${interaction.user.username}`, `${interaction.user.displayAvatarURL()}`)
      .setThumbnail(interaction.guild.iconURL({dynamic:true}))
      .setColor("BLACK")
      .setTitle(`\`\#\`\ Nitro Prices In ${interaction.guild.name}`)
      .setDescription(`

============

**<:NitroGaM:1032657393160564887> Ntiro Gaming 1 Month Gift : 1.8m <:Credits:1032657402966835261>  **


**<a:Ev_NitroC:1032657398667689985> Nitro Classic 1 Month Gift : 800k <:Credits:1032657402966835261>  **


**<:NitroGaM:1032657393160564887> Nitro Gaming 3 Month Code : 250k <:Credits:1032657402966835261>  **


**<:NitroGaM:1032657393160564887> Nitro Gaming 1 Month Code : 10k <:Credits:1032657402966835261>  **


**<:NitroGaM:1032657393160564887> Ntiro Gaming 1 Month Turkey : 800k <:Credits:1032657402966835261>  **


**<:NitroGaM:1032657393160564887> Ntiro Gaming 1 Year Turkey : 6m <:Credits:1032657402966835261>  **


**<a:Ev_NitroC:1032657398667689985> Ntiro Classic 1 Month Turkey : 500k <:Credits:1032657402966835261>  **


**<a:Ev_NitroC:1032657398667689985> Ntiro Classic 1 Year Turkey : 3m <:Credits:1032657402966835261>  **


===========


- **__You Can Mention The Seller Click The Button__**
`)
      .setImage("https://media.discordapp.net/attachments/967015425990852648/968537296498483210/EGS_Discord_Nitro_2560x1440_withlogo_2560x1440-944994658df3b04d0c4940be832da19e.png")

    let row = new MessageActionRow()
      .addComponents(
        new MessageButton()
          .setCustomId(`nitbutton`)
          .setLabel("Mention Seller")
          .setEmoji("<:1029138651403272255:1034020020151398420>")
          .setStyle('SUCCESS')
      );

    interaction.reply({ content: `<@${interaction.user.id}>`, embeds: [nitroembedembed], components: [row] })
  }
  if (interaction.values == "bot") {
    const botembedembed = new MessageEmbed()
      .setAuthor(`By  : ${interaction.user.username}`, `${interaction.user.displayAvatarURL()}`)
      .setFooter(`By  : ${interaction.user.username}`, `${interaction.user.displayAvatarURL()}`)
      .setThumbnail(interaction.guild.iconURL({dynamic:true}))
      .setColor("BLACK")
      .setTitle(`\`\#\`\ Bot Prices In ${interaction.guild.name}`)
      .setDescription(`
**
==============

- <a:bot:1034011807985180682> All In One : 1.5m <:Credits:1032657402966835261> 


- <a:bot:1034011807985180682> Full System Vip Shop Bot : 800K <:Credits:1032657402966835261> 


- <a:bot:1034011807985180682> Full System Bot : 500K <:Credits:1032657402966835261> 


- <a:bot:1034011807985180682> System Bot : 200K <:Credits:1032657402966835261> 


- <a:bot:1034011807985180682> Brodcast Bot : 150K <:Credits:1032657402966835261> 


- <a:bot:1034011807985180682> Avatar Bot : 100K <:Credits:1032657402966835261>


- <a:bot:1034011807985180682> Auto Line & React : 80K <:Credits:1032657402966835261> 


- <a:bot:1034011807985180682> Tax (In Specific Room) : 60K <:Credits:1032657402966835261> 


- <a:bot:1034011807985180682> Tax : 40K <:Credits:1032657402966835261> 


- <a:bot:1034011807985180682> Auto Line With Embed Bot : 40K <:Credits:1032657402966835261> 


- <a:bot:1034011807985180682> Auto Line Withot embed : 20K <:Credits:1032657402966835261> 


- <a:bot:1034011807985180682> Auto React Bot : 15K <:Credits:1032657402966835261>


- <a:bot:1034011807985180682> Roubux Bot : 400K <:Credits:1032657402966835261> 


=======================
**
- **__You Can Mention The Seller Click The Button__**
`)
      .setImage("https://media.discordapp.net/attachments/967015425990852648/968613515873099806/images_4.jpeg")

    let row = new MessageActionRow()
      .addComponents(
        new MessageButton()
          .setCustomId(`botbutton`)
          .setLabel("Mention Seller")
          .setEmoji("<:1029138651403272255:1034020020151398420>")
          .setStyle('SUCCESS')
      );

    interaction.reply({ content: `<@${interaction.user.id}>`, embeds: [botembedembed], components: [row] })
  }
  if (interaction.values == "vote") {
    const botembedembed = new MessageEmbed()
      .setAuthor(`By  : ${interaction.user.username}`, `${interaction.user.displayAvatarURL()}`)
      .setThumbnail(interaction.guild.iconURL({dynamic:true}))
      .setFooter(`By  : ${interaction.user.username}`, `${interaction.user.displayAvatarURL()}`)
      .setColor("BLACK")
      .setTitle(`\`\#\`\ Vote Prices In ${interaction.guild.name}`)
      .setDescription(`Here Is All Vote Prices

================

**<a:13943:1032657853149872138> 1 vote : 2.5k <:Credits:1032657402966835261> **

=================

- **__You Can Mention The Seller Click The Button__**
`)
      .setImage("https://media.discordapp.net/attachments/967015425990852648/968613946653302926/download.jpeg")

    let row = new MessageActionRow()
      .addComponents(
        new MessageButton()
          .setCustomId(`votbutton`)
          .setLabel("Mention Seller")
          .setEmoji("<:1029138651403272255:1034020020151398420>")
          .setStyle('SUCCESS')
      );

    interaction.reply({ content: `<@${interaction.user.id}>`, embeds: [botembedembed], components: [row] })
  }
  if (interaction.values == "uc") {
    const botembedembed = new MessageEmbed()
      .setAuthor(`By  : ${interaction.user.username}`, `${interaction.user.displayAvatarURL()}`)
      .setFooter(`By  : ${interaction.user.username}`, `${interaction.user.displayAvatarURL()}`)
      .setThumbnail(interaction.guild.iconURL({dynamic:true}))
      .setColor("BLACK")
      .setTitle(`\`\#\`\ Uc Prices In ${interaction.guild.name}`)
      .setDescription(`
**
================ Global ================


> <:pubgm_uc:1032665747631132682> 60uc : 20 LE <:Credits:1032657402966835261>


> <:pubgm_uc:1032665747631132682> 180uc : 55 LE <:Credits:1032657402966835261>


> <:pubgm_uc:1032665747631132682> 325uc : 80 LE <:Credits:1032657402966835261>


> <:pubgm_uc:1032665747631132682> 660uc : 150 LE <:Credits:1032657402966835261>


> <:pubgm_uc:1032665747631132682> 985uc : 225 LE <:Credits:1032657402966835261>


> <:pubgm_uc:1032665747631132682> 1800uc : 375 LE <:Credits:1032657402966835261>


> <:pubgm_uc:1032665747631132682> 3850uc : 725 LE <:Credits:1032657402966835261>  


================ Korean ================


> <:pubgm_uc:1032665747631132682> 190uc : 60 LE <:Credits:1032657402966835261>


> <:pubgm_uc:1032665747631132682> 660uc : 160 LE <:Credits:1032657402966835261>


> <:pubgm_uc:1032665747631132682> 1800uc : 430 LE <:Credits:1032657402966835261>


> <:pubgm_uc:1032665747631132682> 3850uc : 840 LE <:Credits:1032657402966835261>


> <:pubgm_uc:1032665747631132682> 8000uc : 1660 LE <:Credits:1032657402966835261> 


=================
**
- **__You Can Mention The Seller Click The Button__**
`)
      .setImage("https://media.discordapp.net/attachments/967015425990852648/968620259592515664/images_5.jpeg")

    let row = new MessageActionRow()
      .addComponents(
        new MessageButton()
          .setCustomId(`ucbutton`)
          .setLabel("Mention Seller")
          .setEmoji("<:1029138651403272255:1034020020151398420>")
          .setStyle('SUCCESS')
      );
    interaction.reply({ content: `<@${interaction.user.id}>`, embeds: [botembedembed], components: [row] })
  }
  if (interaction.values == "boost") {
    const botembedembed = new MessageEmbed()
      .setAuthor(`By  : ${interaction.user.username}`, `${interaction.user.displayAvatarURL()}`)
      .setFooter(`By  : ${interaction.user.username}`, `${interaction.user.displayAvatarURL()}`)
      .setThumbnail(interaction.guild.iconURL({dynamic:true}))
      .setColor("BLACK")
      .setTitle(`\`\#\`\ Boost Prices In ${interaction.guild.name}`)
      .setDescription(`
**
================


- <:boost_boost:1032657399162601648> 2 Boost 1 Month : 60k <:Credits:1032657402966835261>  


- <:boost_boost:1032657399162601648> 2 Boost 3 Month : 300k <:Credits:1032657402966835261>  


=================
**
- **__You Can Mention The Seller Click The Button__**
`)
      .setImage("https://media.discordapp.net/attachments/967015425990852648/968816001149984778/images_6.jpeg")

    let row = new MessageActionRow()
      .addComponents(
        new MessageButton()
          .setCustomId(`bosbutton`)
          .setLabel("Mention Seller")
          .setEmoji("<:1029138651403272255:1034020020151398420>")
          .setStyle('SUCCESS')
      );
    interaction.reply({ content: `<@${interaction.user.id}>`, embeds: [botembedembed], components: [row] })

  }
  if (interaction.values == "spotify") {
    const botembedembed = new MessageEmbed()
      .setAuthor(`By  : ${interaction.user.username}`, `${interaction.user.displayAvatarURL()}`)
      .setFooter(`By  : ${interaction.user.username}`, `${interaction.user.displayAvatarURL()}`)
      .setThumbnail(interaction.guild.iconURL({dynamic:true}))
      .setColor("BLACK")
      .setTitle(`\`\#\`\ Spotify Prices In ${interaction.guild.name}`)
      .setDescription(`

**
================

> <:mega_spotfay:1032666073289465936> Solo 1 Month : 150k  <:Credits:1032657402966835261>

> <:mega_spotfay:1032666073289465936> Duo 1 Month : 200k  <:Credits:1032657402966835261>

> <:mega_spotfay:1032666073289465936> Family 1 Month : 250k  <:Credits:1032657402966835261>

> <:mega_spotfay:1032666073289465936> Solo 3 Month : 300k  <:Credits:1032657402966835261>

=================
**
- **__You Can Mention The Seller Click The Button__**
`)
      .setImage("https://media.discordapp.net/attachments/967015425990852648/968819184979025930/images_1.png")

    let row = new MessageActionRow()
      .addComponents(
        new MessageButton()
          .setCustomId(`spotbutton`)
          .setLabel("Mention Seller")
          .setEmoji("<:1029138651403272255:1034020020151398420>")
          .setStyle('SUCCESS')
      );
    interaction.reply({ content: `<@${interaction.user.id}>`, embeds: [botembedembed], components: [row] })

  }
  if (interaction.values == "shahid") {
    const botembedembed = new MessageEmbed()
      .setAuthor(`By  : ${interaction.user.username}`, `${interaction.user.displayAvatarURL()}`)
      .setFooter(`By  : ${interaction.user.username}`, `${interaction.user.displayAvatarURL()}`)
      .setThumbnail(interaction.guild.iconURL({dynamic:true}))
      .setColor("BLACK")
      .setTitle(`\`\#\`\ Shahid Prices In ${interaction.guild.name}`)
      .setDescription(`
**
=================

- <:899665368761630730:1032666417616650350> Shahid User 1 Month : 80K <:Credits:1032657402966835261>

=================
**
- **__You Can Mention The Seller Click The Button__**
`)
      .setImage("https://media.discordapp.net/attachments/967015425990852648/968820015392514078/images_2.png")

    let row = new MessageActionRow()
      .addComponents(
        new MessageButton()
          .setCustomId(`shabutton`)
          .setLabel("Mention Seller")
          .setEmoji("<:1029138651403272255:1034020020151398420>")
          .setStyle('SUCCESS')
      );
    interaction.reply({ content: `<@${interaction.user.id}>`, embeds: [botembedembed], components: [row] })

  }
  if (interaction.values == "credit") {
    const botembedembed = new MessageEmbed()
      .setAuthor(`By  : ${interaction.user.username}`, `${interaction.user.displayAvatarURL()}`)
      .setFooter(`By  : ${interaction.user.username}`, `${interaction.user.displayAvatarURL()}`)
      .setThumbnail(interaction.guild.iconURL({dynamic:true}))
      .setColor("BLACK")
      .setTitle(`\`\#\`\ Credit Prices In ${interaction.guild.name}`)
      .setDescription(`
**
================

- <:Credits:1032657402966835261>100K : 8 EGP <:drs__vodafone:1032673650270285825>

- <:Credits:1032657402966835261> 500K : 40 EGP <:drs__vodafone:1032673650270285825>

- <:Credits:1032657402966835261> 1M : 80 EGP <:drs__vodafone:1032673650270285825>

=================
**
- **__You Can Mention The Seller Click The Button__**
`)
      .setImage("https://media.discordapp.net/attachments/967015425990852648/968820942522429510/images_7.jpeg")

    let row = new MessageActionRow()
      .addComponents(
        new MessageButton()
          .setCustomId(`crebutton`)
          .setLabel("Mention Seller")
          .setEmoji("<:1029138651403272255:1034020020151398420>")
          .setStyle('SUCCESS')
      );
    interaction.reply({ content: `<@${interaction.user.id}>`, embeds: [botembedembed], components: [row] })

  }
  if (interaction.values == "tiktok") {
    const botembedembed = new MessageEmbed()
      .setAuthor(`By  : ${interaction.user.username}`, `${interaction.user.displayAvatarURL()}`)
      .setFooter(`By  : ${interaction.user.username}`, `${interaction.user.displayAvatarURL()}`)
      .setColor("BLACK")
      .setTitle(`\`\#\`\ Tiktok Prices In ${interaction.guild.name}`)
      .setDescription(`
**
=================

**__Followers__**

- <:TikTok3265:1032657402136383568> 1K(بدون ضمان) = 600k <:Credits:1032657402966835261>

- <:TikTok3265:1032657402136383568> 1k(ضمان شهر) = 900k <:Credits:1032657402966835261>

=================

**__Likes__**

- <:TikTok3265:1032657402136383568> 1k(ضمان شهر) = 300k <:Credits:1032657402966835261>

=================

**__Views__**

- <:TikTok3265:1032657402136383568> 1k(ضمان وصول) = 5k <:Credits:1032657402966835261>

=================
**
- **__You Can Mention The Seller Click The Button__**`)
      .setImage(`https://cdn.smehost.net/dailyrindblogcom-orchardprod/wp-content/uploads/2021/07/TikTok_Banner-1.jpg`)

    let row = new MessageActionRow()
      .addComponents(
        new MessageButton()
          .setCustomId(`tikbutton`)
          .setLabel("Mention Seller")
          .setEmoji("<:1029138651403272255:1034020020151398420>")
          .setStyle('SUCCESS')
      );
     interaction.reply({ content: `<@${interaction.user.id}>`, embeds: [botembedembed], components: [row] })

  }
})

cityteam.on("interactionCreate", interaction => {
  if (!interaction.isButton()) return;

let sellroles = db.get(`sellroles_${interaction.guild.id}` )

  if (interaction.customId == "netflixbutton") {
    
    interaction.channel.send({
      content: `
<a:flower:1032658526683811931> Sorry! Wait Untill The Seller Come
<a:aemoji_:1032657855150567534> Mention : || <@&${sellroles.netflix}> ||`
    })
    interaction.channel.setName(`need-netflix`)
  }
  if (interaction.customId == "insbutton") {
    interaction.channel.send({
      content: `
<a:flower:1032658526683811931> Sorry! Wait Untill The Seller Come
<a:aemoji_:1032657855150567534> Mention : || <@&${sellroles.insta}> ||`
    })
    interaction.deferUpdate()
    interaction.channel.setName(`need-insta`)
  }
  if (interaction.customId == "visbutton") {
    interaction.channel.send({
      content: `
<a:flower:1032658526683811931> Sorry! Wait Untill The Seller Come
<a:aemoji_:1032657855150567534> Mention : || <@&${sellroles.visa}> ||`
    })
    interaction.deferUpdate()
    interaction.channel.setName(`need-visa`)
  }
  if (interaction.customId == "nitbutton") {
    interaction.channel.send({
      content: `
<a:flower:1032658526683811931> Sorry! Wait Untill The Seller Come
<a:aemoji_:1032657855150567534> Mention : || <@&${sellroles.nitro}> ||`
    })
    interaction.deferUpdate()
    interaction.channel.setName(`need-nitro`)
  }
  if (interaction.customId == "botbutton") {
    interaction.channel.send({
      content: `
<a:flower:1032658526683811931> Sorry! Wait Untill The Seller Come
<a:aemoji_:1032657855150567534> Mention : || <@&${sellroles.bot}> ||`
    })
    interaction.deferUpdate()
    interaction.channel.setName(`need-bots`)
  }
  if (interaction.customId == "votbutton") {
    interaction.channel.send({
      content: `
<a:flower:1032658526683811931> Sorry! Wait Untill The Seller Come
<a:aemoji_:1032657855150567534> Mention : || <@&${sellroles.vote}> ||`
    })
    interaction.deferUpdate()
    interaction.channel.setName(`need-votes`)
  }
  if (interaction.customId == "ucbutton") {
    interaction.channel.send({
      content: `
<a:flower:1032658526683811931> Sorry! Wait Untill The Seller Come
<a:aemoji_:1032657855150567534> Mention : || <@&${sellroles.uc}> ||`
    })
    interaction.deferUpdate()
    interaction.channel.setName(`need-uc`)
  }
  if (interaction.customId == "bosbutton") {
    interaction.channel.send({
      content: `
<a:flower:1032658526683811931> Sorry! Wait Untill The Seller Come
<a:aemoji_:1032657855150567534> Mention : || <@&${sellroles.boost}> ||`
    })
    interaction.deferUpdate()
    interaction.channel.setName(`need-boosts`)
  }
  if (interaction.customId == "spotbutton") {
    interaction.channel.send({
      content: `
<a:flower:1032658526683811931> Sorry! Wait Untill The Seller Come
<a:aemoji_:1032657855150567534> Mention : || <@&${sellroles.spotify}> ||`
    })
    interaction.deferUpdate()
    interaction.channel.setName(`need-spotify`)
  }
  if (interaction.customId == "shabutton") {
    interaction.channel.send({
      content: `
<a:flower:1032658526683811931> Sorry! Wait Untill The Seller Come
<a:aemoji_:1032657855150567534> Mention : || <@&${sellroles.shahid}> ||`
    })
    interaction.deferUpdate()
    interaction.channel.setName(`need-shahid`)
  }
  if (interaction.customId == "crebutton") {
    interaction.channel.send({
      content: `
<a:flower:1032658526683811931> Sorry! Wait Untill The Seller Come
<a:aemoji_:1032657855150567534> Mention : || <@&${sellroles.credit}> ||`
    })
    interaction.deferUpdate()
    interaction.channel.setName(`need-credit`)
  }
  if (interaction.customId == "tikbutton") {
    interaction.channel.send({
      content: `
<a:flower:1032658526683811931> Sorry! Wait Untill The Seller Come
<a:aemoji_:1032657855150567534> Mention : || <@&${sellroles.tiktok}> ||`
    })
    interaction.channel.setName(`need-tiktok`)
    interaction.deferUpdate()
  }
    if (interaction.customId == "desibutton") {
    interaction.channel.send({
      content: `
<a:flower:1032658526683811931> Sorry! Wait Untill The Seller Come
<a:aemoji_:1032657855150567534> Mention : || <@&${sellroles.design}> ||`
    })
    interaction.channel.setName(`need-designs`)
    interaction.deferUpdate()
  }
})



////////////////////



cityteam.on('channelCreate' , async(message) => {
  let applycategory = db.get(`appcat_${message.guild.id}`)
  if(message.parentId != applycategory) return;
  setTimeout(() => {    
  message.send({ content: `> ** Click On The Button To Start Team Apply Submition ** <a:810809703831568384:1032658516449697832>
> **برجاء الضغط علي البتن لبدئ التقديم الي طاقم العمل** <a:810809703831568384:1032658516449697832>

<a:807543478594174977:1032657691685945494>ملحوظه : لو مضغطتش علي البتن و كملت مع البوت محدش هيرد عليك
` , components: [
    new MessageActionRow()
    .addComponents(
      new MessageButton()
      .setLabel("Click Here")
      .setStyle("PRIMARY")
      .setCustomId("hh")
    )
  ]})
     }, 2000);  
  cityteam.on('interactionCreate' , async(interaction) => {
    if(interaction.customId == "hh") {
      		const modal = new Modal()
			.setCustomId('myModal')
			.setTitle('Apply Team Submit');
		const rname = new TextInputComponent()
			.setCustomId('rname')
			.setLabel("ما هو اسمك الحقيقي")
			.setStyle('SHORT');

      		const age = new TextInputComponent()
			.setCustomId('age')
			.setLabel("ما هو عمرك")
			.setStyle('SHORT');

      		const svcount = new TextInputComponent()
			.setCustomId('svcount')
			.setLabel("ما عدد السيرفرات الي انتا شغال فيها")
			.setStyle('SHORT');

      		const fbcount = new TextInputComponent()
			.setCustomId('fb')
			.setLabel("معاك 25 فيدباك نعم او لا")
			.setStyle('SHORT');

      		const roles = new TextInputComponent()
			.setCustomId('roles')
			.setLabel("ما هي رتب البيع التي تقدم عليها انت")
			.setStyle('SHORT');
      
		const name = new MessageActionRow().addComponents(rname);
		const agge = new MessageActionRow().addComponents(age);
      const svvcount = new MessageActionRow().addComponents(svcount);
      const fbvcount = new MessageActionRow().addComponents(fbcount);
      const rovles = new MessageActionRow().addComponents(roles);
		// Add inputs to the modal
		modal.addComponents(name , agge,svvcount,fbvcount,rovles);
		// Show the modal to the user
		await interaction.showModal(modal);

        cityteam.on('interactionCreate', async(interaction) => {
	if (!interaction.isModalSubmit()) return;

	if (interaction.customId === 'myModal') {
    
    const name = interaction.fields.getTextInputValue('rname');
    const rname = interaction.fields.getTextInputValue('age');
    const rrname = interaction.fields.getTextInputValue('svcount');
    const rrrname = interaction.fields.getTextInputValue('fb');
    const rrrrname = interaction.fields.getTextInputValue('roles');
await interaction.reply({ content: `
> The Apply Team Has Been Submited , Please Put Here The Feedbacks If You Dont Have You Will Pay 250k
> تم عمل التقديم , برجاء وضع الفيدباكات هنا و لو مش معاك فيدباك ف هتطر تدفع 250 الف ضمان

لو مش هتعمل حاجه من الاتنين ف محدش هيرد عليك`,embeds: [
      new MessageEmbed()
        .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
        .setAuthor({ name: interaction.guild.name , iconURL: interaction.guild.iconURL({dynamic: true}) })
        .setFooter({ text: interaction.guild.name , iconURL: interaction.guild.iconURL({dynamic: true}) })
        .setTimestamp()
      .setDescription(`
\`\`\` New Apply Team Submition \`\`\`

> Seller Name : ${name} <a:nqrheart:1034016583103815720>

> Seller Age: ${rname} <a:tszemoji_318:1032657532130435092>

> Seller Servers Count He Work In : ${rrname} <a:807543478594174977:1032657691685945494>

> Does He Have Feedback : ${rrrname} <a:Yred:1032658857673117737>

> Sell Roles : ${rrrrname} 
`)

    ] });
    interaction.channel.send(`> || @here ||`)
    
	}
});
    }
  })
})





cityteam.login(process.env.token);