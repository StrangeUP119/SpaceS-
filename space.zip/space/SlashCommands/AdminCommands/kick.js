const { EmbedBuilder , Discord , PermissionsBitField } = require('discord.js');

module.exports = {
  name:"kick",
  description:"This Command Is To Kick Someone From Your Server.!",
  options : [{
    name : "user",
    description: "User To Kick Him From Ur Server .!",
    type: 6,
    required: true,
  }],

    async execute(interaction, client) {
    try {
       if (!interaction.member.permissions.has("BAN_MEMBERS")) return interaction.reply(`** 😕 You don't have permissions **`);
    
  
    let user = interaction.options.getMember('user')
    if (!user) return interaction.reply(`** 😕 Please mention or id **`)
    if(user.roles.highest.position > interaction.guild.members.resolve(interaction.user).roles.highest.position) return 
  interaction.reply(`** ❌ You can't Kick this user **`)
    if(user.roles.highest.position > interaction.guild.members.resolve(client.user).roles.highest.position) return interaction.reply(`** ❌ You can't Kick this user **`)
    user.kick().then(() => interaction.reply(`**✅ @${user.user.username} kicked from the server!**`)).catch(err => interaction.reply(err))  
} catch (err) {
      console.log(err)
  }
 }
}
