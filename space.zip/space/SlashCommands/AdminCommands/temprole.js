const { MessageEmbed } = require('discord.js');
let ms = require('ms')
const { PermissionsBitField } = require('discord.js');
module.exports = {
  name:"temprole",
  description:"This Command Is To Give Someone a Role For A While Of A Time",
  options: [{
    name : "user",
    description: "User To Give Him The Temporary Role",
    type: 6,
    required: true
  } , {
    name : "role",
    description: "Role To Give To The User",
    type: 8,
    required: true
  } , {
    name : "time",
    description: "The Time Of The Role",
    type: 3,
    required: true
  }],

    async execute(interaction, client) {
    try {
      let user = interaction.options.getMember('user')
      let role = interaction.options.getRole("role")
      let time = interaction.options.getString("time")
      
      if (!interaction.member.permissions.has('MANAGE_CHANNELS')) return interaction.reply(`** 😕 You don't have permissions **`);
        if (user.id === interaction.user.id) return interaction.reply("لا يمكن اعطاء رتبه لنفسك")
        if (user.id === client.user.id) return interaction.reply("لا يمكن اعطاء رتبه للبوت")
      
               user.roles.add(role)
      interaction.reply({  content : `> ** Done Gived ${user} , Role ${role} , For ${ms(ms(time))}.**`});
        setTimeout(() => {
            user.roles.remove(role)
        }, ms(time))
} catch (err) {
      interaction.reply(`** 😕 I couldn't edit the channel permissions. Please check my permissions and role position.**`);
  }
 }
}
