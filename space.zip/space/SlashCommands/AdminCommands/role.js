const { MessageEmbed } = require('discord.js');
let ms = require('ms')
const { PermissionsBitField } = require('discord.js');
module.exports = {
  name:"role",
  description:"This Command Is For Giving Someone Role.!",
  options: [{
    name : "user",
    description: "User To Give Him Role",
    type: 6,
    required: true
  } , {
    name : "role",
    description: "Role To Give To User",
    type: 8,
    required: true
  }],

    async execute(interaction, client) {
    try {
      let user = interaction.options.getMember('user')
      let role = interaction.options.getRole("role")
      
      if (!interaction.member.permissions.has('MANAGE_CHANNELS')) return interaction.reply(`** 😕 You don't have permissions **`);
      
        if (user.id === interaction.user.id) return interaction.reply("لا يمكن اعطاء رتبه لنفسك")
        if (user.id === client.user.id) return interaction.reply("لا يمكن اعطاء رتبه للبوت")
      
               user.roles.add(role)
      interaction.reply({  content : `> ** Done Gived ${user} , Role ${role} **`});
} catch (err) {
      interaction.reply(`** 😕 I couldn't edit the channel permissions. Please check my permissions and role position.**`);
  }
 }
}
