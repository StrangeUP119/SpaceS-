const { EmbedBuilder , Discord , PermissionsBitField } = require('discord.js');

module.exports = {
  name:"showall",
  description:"This Command Is To Show All Channels",

    async execute(interaction, client) {
    try {
              if(!interaction.member.permissions.has('MANAGE_CHANNELS')) return interaction.reply(`** 😕 You don't have permissions **`); 
  


interaction.guild.channels.cache.each((channel) => { 
   channel.permissionOverwrites.edit(channel.guild.roles.everyone, {
            ViewChannel: true
            });
});
  interaction.reply("> ** Done __Showed__ All Server Channels**")
} catch (err) {
     interaction.reply(`** 😕 I couldn't edit the channel permissions. Please check my permissions and role position.**`);
  }
 }
}
