const { EmbedBuilder , Discord , PermissionsBitField } = require('discord.js');

module.exports = {
  name:"hide",
  description:"This Command Is To Hide Some Channel",

    async execute(interaction, client)  {
    try {
      if(!interaction.member.permissions.has('MANAGE_CHANNELS')) return interaction.reply(`** 😕 You don't have permissions **`); 
  

let everyone = interaction.guild.roles.everyone;
interaction.channel.permissionOverwrites.create(everyone, {
            ViewChannel: false
            }).then(() => {
interaction.reply(`**✅  ${interaction.channel} Done Hided this room.**`)
})
   
} catch (err) {
    interaction.reply(`** 😕 I couldn't edit the channel permissions. Please check my permissions and role position.**`);
  }
 }
}
