const { EmbedBuilder, Discord, PermissionsBitField } = require('discord.js');

module.exports = {
  name:"lock",
  description:"This Command Is To Lock Some Channel",

    async execute(interaction, client) {
    try {
      if (!interaction.member.permissions.has('MANAGE_CHANNELS')) return interaction.reply(`** 😕 You don't have permissions **`);

      let everyone = interaction.guild.roles.cache.find(hyper => hyper.name === '@everyone');
      interaction.channel.permissionOverwrites.edit(everyone, {
        SendMessages : false
      }).then(() => {
        interaction.reply(`**✅  ${interaction.channel} Done Locked this room.**`)
      })

    } catch (err) {
     interaction.reply(`** 😕 I couldn't edit the channel permissions. Please check my permissions and role position.**`);
    }
  }
}
