const { EmbedBuilder , Discord , PermissionsBitField } = require('discord.js');

module.exports = {
  name:"unban",
  description:"This Command Is For Unbaning Someone From Ur Server .!",
  options : [{
    name : "id",
    description: "Id Of The User To Unban Him",
    type: 3,
    required: true,
  }],

    async execute(interaction, client) {
    try {
if (!interaction.member.permissions.has('BAN_MEMBERS')) return interaction.reply(`** 😕 You don't have permission **`);
      
    let id = interaction.options.getString('id')
    if(isNaN(id)) {
       return interaction.reply(`** 😕 Please Provide Me A Valuied Id**`);
    } else {
interaction.guild.members.unban(id).then(mmm => {
        interaction.reply(`✅** ${mmm.tag} unbanned!**`)
      }).catch(err => interaction.reply(`**I can't find this member in bans list**`));
      }
      
} catch (err) {
    interaction.reply(`** 😕 I couldn't edit the channel permissions. Please check my permissions and role position.**`);
  }
 }
}
