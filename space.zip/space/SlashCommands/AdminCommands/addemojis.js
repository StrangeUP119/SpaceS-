
const { SlashCommandBuilder } = require('@discordjs/builders');
const { default: axios } = require('axios');
const { MessageEmbed } = require("discord.js")
const Discord = require("discord.js")
module.exports = {
    data: new SlashCommandBuilder()
    .setName("addemojis")
    .setDescription("This Command Is To Add Multiple Emojis To Ur Server")
    .addStringOption((option) => option.setName('emoji').setDescription('The Emoji U Need To Add To Ur Server').setRequired(true))
    .addStringOption((option) => option.setName('name').setDescription('Name Of The Added Emojis').setRequired(false)),
    async execute(client, interaction) {
        /* Check for permissions */
        if(!interaction.member.permissions.has("MANGE_EMOJIS")) 
        return interaction.reply({ content: "You do not have enough permissions to use this command." })
        let name = interaction.options.getString("name")
if (!name) name = "realbotup"
        const emojis = interaction.options.getString('emoji').match(/<?(a)?:?(\w{2,32}):(\d{17,19})>?/gi);
let emojisArra = []
emojis.forEach((emote) => {
  let emoji = Discord.Util.parseEmoji(emote);
  if (emoji.id) {
    const Link = `https://cdn.discordapp.com/emojis/${emoji.id}.${
      emoji.animated ? "gif" : "png" 
    }`;
interaction.guild.emojis.create(`${Link}`, `${name}`).then((em) => {
        emojisArra.push(em.toString())
          if (emojis.length == emojisArra.length) {
    interaction.reply({embeds : [
      new MessageEmbed()
.setTitle("Done Add Emojis")
      .setColor("RANDOM")
      .addField("Emojis",`${emojisArra.map(e => e).join(',')}`)
    ]})
      emojisArra = []
  }
    })
  }
})
               }}