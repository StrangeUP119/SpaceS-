const { EmbedBuilder, Discord, PermissionsBitField } = require('discord.js');

module.exports = {
  name:"unlock",
  description:"This Command Is To Unlock Some Channel",

    async execute(interaction, client) {
    try {
      if (!interaction.member.permissions.has('ADMINSTRATOR')) return interaction.reply(`** 😕 You don't have permissions **`);

      let everyone = interaction.guild.roles.cache.find(hyper => hyper.name === '@everyone');
      interaction.channel.permissionOverwrites.edit(everyone, {
        SendMessages : true
      }).then(() => {
        interaction.reply(`**✅  ${interaction.channel} Done Unlcok this room.**`)
      })

    } catch (err) {
   interaction.reply(`** 😕 I couldn't edit the channel permissions. Please check my permissions and role position.**`);
    }
  }
}
