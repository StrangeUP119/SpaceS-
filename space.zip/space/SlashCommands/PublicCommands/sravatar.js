const { EmbedBuilder , Discord , ActionRowBuilder, ButtonBuilder } = require('discord.js');
module.exports = {
  name:"sravatar",
  description:"This Command Is Used For Showing Server Avatar .!",

   async execute(interaction, client) {
    try {
    var button = new ActionRowBuilder()
   .addComponents(
     new ButtonBuilder()
      .setStyle('Link') 
.setLabel(`Download Server Avatar`)
.setURL((`${interaction.guild.iconURL({dynamic: true, size: 4096})}`))
   ); 
interaction.reply({embeds: [
          new EmbedBuilder()
        .setAuthor({ name: interaction.user.tag, iconURL: interaction.user.displayAvatarURL({ dynamic: true}) })
     .setFooter({ text: `Requested by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
   .setDescription(`[Server Avatar link](${interaction.guild.iconURL({dynamic: true, size: 4096})})`)
   .setImage(`${interaction.guild.iconURL({dynamic: true, size: 4096})}`)
] , components: [button]})

} catch (err) {
      interaction.reply({content:"> This Server Has No Avatar 😒"})
  }
 }
}