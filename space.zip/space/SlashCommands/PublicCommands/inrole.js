const { EmbedBuilder , Discord } = require('discord.js');
const moment = require('moment')
module.exports = {
  name: "inrole",
  description: "This Command Is To Get Information About Role",
  options: [{
    name: "role",
    description: "Role You Wanna Get Info About It .!",
    type: 8,
    required: true,
  }],

 async execute(interaction, client) {
    try {
    let role = interaction.options.getRole('role')
    let map = interaction.guild.roles.cache.get(role.id).members.map(rr => `**<@${rr.id}> ( ${rr.id} )**`).join("\n")
        
   interaction.reply({ embeds: [       
     new EmbedBuilder()
     .setTitle(` Info About \`${role.name}\`  `)
    .setColor('#7800FF')
     .setDescription(` **Role Name : **\`${role.name}\`

 **Members Count Have This Role :** \`${interaction.guild.roles.cache.get(role.id).members.size}\`


 **Members :**
${map}


 **Role Is Created At : **\`${moment(role.createdAt).format('DD/MM/YYYY h:mm' )} \`

`)
     .setTimestamp()
     .setAuthor({ name: interaction.user.tag, iconURL: interaction.user.displayAvatarURL({ dynamic: true}) })
     .setFooter({ text: `Requested by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
 ], split: true})


} catch (err) {
      console.log(err)
  }
 }
}