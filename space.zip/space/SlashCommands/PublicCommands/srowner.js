const { MessageEmbed, Discord } = require('discord.js');
module.exports = {
  name:"srowner",
  description:"This Command Is Used For Showing Server Owner .!",

 async execute(interaction, client) {
    try {
      interaction.reply({ content: `<a:ass_:998754918762557610> The Server Owner Is : <@!${interaction.guild.ownerId}> <a:emoji_271:997870576561553439>` })
    } catch (err) {
      console.log(err)
    }
  }
}