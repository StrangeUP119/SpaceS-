const { EmbedBuilder , Discord , ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
module.exports = {
  name:"avatar",
  description:"This Command Is To Get Avatar Of SomeUser .!",
  options : [{
    name: "user",
    description : "The User You Wanna Get His Avatar .!",
    type : 6,
    required: false,
  }],

  async execute(interaction, client) {
    try {
     let ff = interaction.options.getUser('user') || interaction.member;    
        let userr = interaction.member.guild.members.cache.get(ff.id)

    var button = new ActionRowBuilder()
   .addComponents(
     new ButtonBuilder()
      .setStyle('Link') 
.setLabel(`DOWNLOAD AVATAR`)
.setURL(userr.user.displayAvatarURL({ dynamic: true}))); 

    
interaction.reply({embeds: [
          new EmbedBuilder()
        .setAuthor({ name: interaction.user.tag, iconURL: interaction.user.displayAvatarURL({ dynamic: true}) })
     .setFooter({ text: `Requested by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
   .setDescription(`[Avatar link](${userr.user.displayAvatarURL({dynamic: true, size: 4096})})`)
   .setImage(userr.user.displayAvatarURL({ dynamic: true, size: 4096}))
] , components: [button]})

} catch (err) {
      console.log(err)
  }
 }
}