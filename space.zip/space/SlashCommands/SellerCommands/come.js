const { EmbedBuilder , Discord , PermissionsBitField } = require('discord.js');
let db = require('pro.db')
module.exports = {
  name:"come",
  description:"This Command Is To Send SomeOne Private To Come To Room.!",
  options : [{
    name : "user",
    description: "User To Send Him Private",
    type: 6,
    required: true,
  }],

  async execute(interaction, client) {
    try {
      let user = interaction.options.getUser("user")
      let dbx = db.get(`srlink_${interaction.guild.id}`)
      if(dbx == null) dbx = "https://discord.gg/undifined"
          interaction.reply(`
> **Done Send Private to ${user}** <a:flower:1032658526683811931>

> **Please Wait Come Seller ** <a:Yred:1032658857673117737>
`)
    user.send(`> \`-\` <a:aemoji_:1032657855150567534> Sorry For Disturbance You Have Requested Here <a:ss_3:1034193554521718885> 

-

> \`-\` <a:emoji_42:1034193558728609792> Ticket : ${interaction.channel} <a:emoji_43:1034193560108539945> 

-

> \`-\` <a:emoji_55:1034193557256421457> Server Link : { ${dbx} } <a:810809703831568384:1032658516449697832> `)
      
} catch (err) {
      console.log(err)
  }
 }
}
