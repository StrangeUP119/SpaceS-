const { EmbedBuilder , Discord , PermissionsBitField, ActionRowBuilder , ButtonBuilder } = require('discord.js');
module.exports = {
  name:"dm",
  description:"This Command Is To Send SomeOne Private A Text To Come Room.!",
  options : [{
    name : "user",
    description: "User To Send Him Private",
    type: 6,
    required: true,
  } , {
    name : "text",
    description: "Text To Send The User",
    type: 3,
    required: true,
  }],

  async execute(interaction, client) {
    try {
      let user = interaction.options.getUser("user")
      let text = interaction.options.getString("text")
          interaction.reply(`
> **Done Send Private to ${user}** <a:flower:1032658526683811931>

> **Please Wait Come Seller ** <a:Yred:1032658857673117737>
`)
    user.send({ content: `${text} \nSent From ${interaction.channel}\n${user} <a:Crown_dark_red:1047281448123650048>` , components : [
              new ActionRowBuilder()
              .addComponents(
                new ButtonBuilder()
                .setDisabled(true)
                .setLabel(`Sent From ${interaction.guild.name}`)
                .setStyle("Secondary")
                .setCustomId("kosomkolelcopypasters")
              )
    ]})
      
} catch (err) {
      console.log(err)
  }
 }
}
