

const { SlashCommandBuilder, ChatInputCommandInteraction, Client,EmbedBuilder ,AttachmentBuilder} = require('discord.js');
const Canvas = require('canvas')
let db = require('pro.db')

module.exports = {
    data: new SlashCommandBuilder()
        .setName('profile')
        .setDescription('To Get Your RealBot Profile!')
  .addUserOption((option) => 
    option.setName("user").setDescription("User To Get His Profile").setRequired(false)
  ),
    async execute(interaction, client) {
      
            let user = interaction.options.getUser('user') || interaction.user;

      let credit = db.get(`offersaddf_${user.id}`)
      if(credit == null) credit = 0
      
//
      let rep = db.get(`feedadsf_${user.id}`)
      if(rep == null) rep = 0

      //
      let levelll = db.get(`level_${user.id}`)
    if(levelll == null) {
      db.set(`level_${user.id}` , {
        xp : 0,
        nid : user.id
      })
    }
      let levell = db.get(`level_${user.id}`)
      let level = levell.xp;
            
             const canvasp = Canvas.createCanvas(512, 512); // هنا مقاسات الصوره 
      
    const ctx = canvasp.getContext('2d') // هنا الصوره 2d او 3d الخ
    
    const background = await Canvas.loadImage('https://cdn.discordapp.com/attachments/1074123641056403469/1075902180873216101/HH.png'); // هنا الخلفيه تحط فيها المسار بتاع الصوره 
    ctx.drawImage(background, 0, 0, canvasp.width, canvasp.height); // هنا ةمقاسات الخلفيه سيبها زي مهي
    const cutie = await Canvas.loadImage('https://cdn.discordapp.com/attachments/1074123641056403469/1075902180873216101/HH.png'); // هنا مسار الصوره
    ctx.drawImage(cutie, 25, 25, 0, 0);       

      ctx.font = "19px Arial";
      ctx.fillStyle = "white";
      ctx.fillText(level, 40, 275);

      
      ctx.fillStyle = "white";
      ctx.fillText("+"+rep, 45, 365);

      
      ctx.fillStyle = "white";
      ctx.fillText(credit, 55, 455);
      
      ctx.font = "25px Arial";
      ctx.fillStyle = "white";
      ctx.fillText(user.username , 220 , 115);
                 
        
        

        ctx.beginPath();
        ctx.arc(100, 100, 80, 0, 4 * Math.PI);
        ctx.closePath();
        ctx.clip();
        let lllcc = await Canvas.loadImage(user.displayAvatarURL().replace("webp" , "png"));
        ctx.drawImage(lllcc , 15 , 15 , 155 , 155)
      
    const attachment = new AttachmentBuilder(canvasp.toBuffer(), 'image.jpeg'); 
    
        
    interaction.reply({ files: [attachment]}); 
      

    },
};